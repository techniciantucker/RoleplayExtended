client_script 'client.lua'

exports {
    'IsCinema',
    'EnterCinema',
    'ExitCinema'
}